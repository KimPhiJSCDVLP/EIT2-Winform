﻿
namespace StudentManagement
{
    partial class StudentManagement
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCategory = new System.Windows.Forms.Button();
            this.btnBusiness = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.lb_ApplicationName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCategory
            // 
            this.btnCategory.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCategory.Location = new System.Drawing.Point(200, 164);
            this.btnCategory.Name = "btnCategory";
            this.btnCategory.Size = new System.Drawing.Size(125, 35);
            this.btnCategory.TabIndex = 0;
            this.btnCategory.Text = "Danh mục";
            this.btnCategory.UseVisualStyleBackColor = false;
            this.btnCategory.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnBusiness
            // 
            this.btnBusiness.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBusiness.Location = new System.Drawing.Point(345, 164);
            this.btnBusiness.Name = "btnBusiness";
            this.btnBusiness.Size = new System.Drawing.Size(125, 35);
            this.btnBusiness.TabIndex = 0;
            this.btnBusiness.Text = "Nghiệp vụ";
            this.btnBusiness.UseVisualStyleBackColor = false;
            this.btnBusiness.Click += new System.EventHandler(this.btnBusiness_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReport.Location = new System.Drawing.Point(492, 164);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(125, 35);
            this.btnReport.TabIndex = 0;
            this.btnReport.Text = "Báo cáo";
            this.btnReport.UseVisualStyleBackColor = false;
            // 
            // lb_ApplicationName
            // 
            this.lb_ApplicationName.Font = new System.Drawing.Font("SnowCap BT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lb_ApplicationName.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lb_ApplicationName.Location = new System.Drawing.Point(252, 269);
            this.lb_ApplicationName.Name = "lb_ApplicationName";
            this.lb_ApplicationName.Size = new System.Drawing.Size(300, 50);
            this.lb_ApplicationName.TabIndex = 1;
            this.lb_ApplicationName.Text = "Quản lý bảng điểm cá nhân của sinh viên";
            this.lb_ApplicationName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // StudentManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_ApplicationName);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnBusiness);
            this.Controls.Add(this.btnCategory);
            this.Name = "StudentManagement";
            this.Text = "Quản lý bảng điểm cá nhân";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCategory;
        private System.Windows.Forms.Button btnBusiness;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label lb_ApplicationName;
    }
}

