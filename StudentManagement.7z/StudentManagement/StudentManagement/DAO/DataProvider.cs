﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace StudentManagement.DAO
{
    class DataProvider
    {
        private static DataProvider instance;
        public DataProvider() {}
        private string connectionString = @"Data Source=.\SQLEXPRESS; Initial Catalog = S4_N10_QLDiemSV; User Id=evolution; Password=123456";
        static object key = new object();
        public static DataProvider Instance
        {
            get
            {
                lock (key)
                {
                    if (instance == null)
                    {
                        instance = new DataProvider();
                    }
                }
                return instance;
            }
        }

        // Thuc thi cau lenh va tra ve ket qua la danh sach du lieu (select ...)
        public DataTable ExcuteQuery(string query, Object[] pamameter = null)
        {
            var data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (pamameter != null)
                {
                    string[] listParam = query.Split(' ');
                    //pattern @
                    int n = 0;
                    foreach (var item in listParam)
                    {
                        if (item.Contains("@"))
                        {
                            command.Parameters.AddWithValue(item, pamameter[n]);
                            n++;
                        }
                    }
                }

                // trung gian qua mot cai SqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        // Thuc thi truy van vi du nhu insert, update, delete
        public int ExcuteNonQuery(string query, Object[] pamameter = null)
        {
            var rs = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (pamameter != null)
                {
                    string[] listParam = query.Split(' ');
                    //pattern @
                    int n = 0;
                    foreach (var item in listParam)
                    {
                        if (item.Contains("@"))
                        {
                            command.Parameters.AddWithValue(item, pamameter[n]);
                            n++;
                        }
                    }
                }
                rs = command.ExecuteNonQuery();
                connection.Close();
            }
            return rs;
        }

        public object ExcuteScalar(string query, Object[] pamameter = null)
        {
            object rs = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (pamameter != null)
                {
                    string[] listParam = query.Split(' ');
                    //pattern @
                    int n = 0;
                    foreach (var item in listParam)
                    {
                        if (item.Contains("@"))
                        {
                            command.Parameters.AddWithValue(item, pamameter[n]);
                            n++;
                        }
                    }
                }
                rs = command.ExecuteScalar();
                connection.Close();
            }
            return rs;
        }
    }
}
