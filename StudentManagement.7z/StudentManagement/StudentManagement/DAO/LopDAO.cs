﻿using StudentManagement.DTO;
using System.Collections.Generic;
using System.Data;

namespace StudentManagement.DAO
{
    public class LopDAO
    {
        private static LopDAO instance;
        public LopDAO() { }
        static object key = new object();
        public static LopDAO Instance
        {
            get
            {
                lock (key)
                {
                    if (instance == null)
                    {
                        instance = new LopDAO();
                    }
                }
                return instance;
            }
        }

        // get danh sach lop
        public List<Lop> GetList()
        {
            var list = new List<Lop>();
            DataTable dataTable = DataProvider.Instance.ExcuteQuery("SELECT * FROM Lop");
            if (dataTable != null)
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    Lop Lop = new Lop(row);
                    list.Add(Lop);
                }
            }
            return list;
        }
    }
}

