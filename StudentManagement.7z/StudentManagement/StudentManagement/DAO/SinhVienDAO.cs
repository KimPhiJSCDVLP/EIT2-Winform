﻿using StudentManagement.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace StudentManagement.DAO
{
    public class SinhVienDAO
    {
        // crud
        private static SinhVienDAO instance;
        public SinhVienDAO() { }
        static object key = new object();
        public static SinhVienDAO Instance
        {
            get
            {
                lock (key)
                {
                    if (instance == null)
                    {
                        instance = new SinhVienDAO();
                    }
                }
                return instance;
            }
        }

        // get danh sach sinh vien
        public List<SinhVien> GetList()
        {
            var list = new List<SinhVien>();
            DataTable dataTable = DataProvider.Instance.ExcuteQuery("SELECT * FROM SinhVien");
            if (dataTable != null)
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    SinhVien sinhVien = new SinhVien(row);
                    list.Add(sinhVien);
                }
            }
            return list;
        }
        // get sinh vien by id
        public SinhVien GetSinhVienById(string sinhVienId)
        {
            var query = $"SELECT * FROM SinhVien WHERE IDSinhVien = '{ sinhVienId}'";
            DataTable dataTable = DataProvider.Instance.ExcuteQuery(query);
            if (dataTable != null)
            {
                if (dataTable.Rows.Count != 0)
                    return new SinhVien(dataTable.Rows[0]);
                else
                    return null;
            }
            else
            {
                return null;
            }
        }
        // them sinh vien
        public int Create(SinhVienDTO sinhVienDTO)
        {
            string dateOfBirth = sinhVienDTO.NgaySinh.ToString("yyyy-MM-dd");
            try
            {
                var query = $"INSERT INTO SinhVien(IDSinhVien, HoTen, NgaySinh, QueQuan, DiaChiHT, GioiTinh, IDLop) " +
                    $"VALUES ('{sinhVienDTO.IDSinhVien}', N'{sinhVienDTO.HoTen}', '{dateOfBirth}', N'{sinhVienDTO.QueQuan}', N'{sinhVienDTO.DiaChiHT}', N'{sinhVienDTO.GioiTinh}', '{sinhVienDTO.IDLop}')";
                var rs = DataProvider.Instance.ExcuteNonQuery(query);
                return rs;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        // cap nhat sinh vien
        public int Update(SinhVienDTO sinhVienDTO)
        {
            string dateOfBirth = sinhVienDTO.NgaySinh.ToString("yyyy-MM-dd");
            try
            {
                var query = $"UPDATE SinhVien SET HoTen = N'{sinhVienDTO.HoTen}', " +
                    $"NgaySinh = '{dateOfBirth}', QueQuan = N'{sinhVienDTO.QueQuan}', DiaChiHT = N'{sinhVienDTO.DiaChiHT}', GioiTinh = N'{sinhVienDTO.GioiTinh}', IDLop = '{sinhVienDTO.IDLop}'" +
                    $" WHERE IDSinhVien = '{sinhVienDTO.IDSinhVien}'";
                var rs = DataProvider.Instance.ExcuteNonQuery(query);
                return rs;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        // xoa sinh vien
        public int Delete(string idSinhVien)
        {
            try
            {
                var query = $"DELETE SinhVien WHERE IDSinhVien = '{idSinhVien}'";
                var rs = DataProvider.Instance.ExcuteNonQuery(query);
                return rs;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        // tim kiem
        public List<SinhVien> Search(string search)
        {
            var listRs = new List<SinhVien>();
            var query = $"SELECT * FROM SinhVien WHERE IDSinhVien LIKE '%{search}%' OR HoTen LIKE '%{search}%' OR GioiTinh LIKE '%{search}%'" +
                $"OR QueQuan LIKE '%{search}%' OR DiaChiHT LIKE '%{search}%' OR IDLop LIKE '%{search}%'";
            DataTable dataTable = DataProvider.Instance.ExcuteQuery(query);
            if (dataTable != null)
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    SinhVien sinhVien = new SinhVien(row);
                    listRs.Add(sinhVien);
                }
            }
            return listRs;
        }
    }
}
