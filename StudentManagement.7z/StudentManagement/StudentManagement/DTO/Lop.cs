﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace StudentManagement.DTO
{
    public class Lop
    {
        public string IDLop { get; set; }
        public string TenLop { get; set; }
        public Lop(DataRow row)
        {
            this.IDLop = row["IDLop"].ToString();
            this.TenLop = row["TenLop"].ToString();
        }
        public Lop(string idLop, string tenLop)
        {
            this.IDLop = idLop;
            this.TenLop = tenLop;
        }
        public Lop() { }
    }
}
