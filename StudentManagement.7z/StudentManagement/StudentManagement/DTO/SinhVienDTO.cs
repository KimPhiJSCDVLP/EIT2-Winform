﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentManagement.DTO
{
    public class SinhVienDTO
    {
        public string IDSinhVien { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string QueQuan { get; set; }
        public string DiaChiHT { get; set; }
        public string IDLop { get; set; }
    }
}
