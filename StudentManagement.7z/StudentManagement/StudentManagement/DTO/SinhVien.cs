﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace StudentManagement.DTO
{
    public class SinhVien
    {
        public string IDSinhVien { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string QueQuan { get; set; }
        public string DiaChiHT { get; set; }
        public string KhoaDki { get; set; }
        public int SoTCDaDat { get; set; }
        public int SoTCDaDki { get; set; }
        public float DiemTichLuy { get; set; }
        public string IDLop { get; set; }

        public SinhVien(DataRow row)
        {
            this.IDSinhVien = row["IDSinhVien"].ToString();
            this.HoTen = row["HoTen"].ToString();
            this.QueQuan = row["QueQuan"].ToString();
            this.DiaChiHT = row["DiaChiHT"].ToString();
            this.GioiTinh = row["GioiTinh"].ToString();
            this.IDLop = row["IDLop"].ToString();
            this.KhoaDki = row["KhoaDki"].ToString();
            if (string.IsNullOrEmpty(row["SoTCDaDat"].ToString()))
                this.SoTCDaDat = 0;
            else
                this.SoTCDaDat = int.Parse(row["SoTCDaDat"].ToString());
            if (string.IsNullOrEmpty(row["SoTCDaDki"].ToString()))
                this.SoTCDaDki = 0;
            else
                this.SoTCDaDki = int.Parse(row["SoTCDaDki"].ToString());
            if (string.IsNullOrEmpty(row["DiemTichLuy"].ToString()))
                this.DiemTichLuy = 0;
            else
                this.DiemTichLuy = float.Parse(row["DiemTichLuy"].ToString());
            this.NgaySinh = DateTime.Parse(row["NgaySinh"].ToString());
        }
        public SinhVien(string idSinhVien, string hoTen, string queQuan, string dichiHT, string gioiTinh, string idLop, string khoaDki, int spTCDaDat,
            int soTCDaDki, float diemTichLuy)
        {
            this.IDSinhVien = idSinhVien;
            this.HoTen = hoTen;
            this.QueQuan = queQuan;
            this.DiaChiHT = dichiHT;
            this.GioiTinh = gioiTinh;
            this.IDLop = idLop;
            this.KhoaDki = khoaDki;
            this.SoTCDaDat = spTCDaDat;
            this.SoTCDaDki = soTCDaDki;
            this.DiemTichLuy = diemTichLuy;
        }
        public SinhVien() { }
    }
}
