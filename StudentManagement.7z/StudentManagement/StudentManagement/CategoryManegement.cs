﻿using StudentManagement.DAO;
using StudentManagement.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class CategoryManegement : Form
    {
        List<SinhVien> sinhViens = null;
        List<Lop> lops = null;
        public CategoryManegement()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData(bool isRefresh = false)
        {
            // nhan du lieu sinh vien tu database
            sinhViens = LoadDataSinhViens();
            DataTable dataTable = CustomHeaderText();
            dtgStudents.DataSource = DataTranfer(dataTable, sinhViens);
            if (!isRefresh)
            {
                lops = LoadDataClass();
                foreach (var item in lops)
                {
                    cbbClass.Items.Add(item.IDLop);
                }
            }
        }
        private List<Lop> LoadDataClass()
        {
            return LopDAO.Instance.GetList();
        }
        private List<SinhVien> LoadDataSinhViens()
        {
            return SinhVienDAO.Instance.GetList();
        }
        private DataTable CustomHeaderText()
        {
            var table = new DataTable();
            table.Columns.Add("STT");
            table.Columns.Add("Mã sinh viên");
            table.Columns.Add("Họ tên");
            table.Columns.Add("Ngày sinh");
            table.Columns.Add("Quê quán");
            table.Columns.Add("Địa chỉ HT");
            table.Columns.Add("Khóa Đký");
            table.Columns.Add("Số TC đã đạt");
            table.Columns.Add("Số TC Đký");
            table.Columns.Add("Điểm tích lũy");
            table.Columns.Add("Mã lớp");
            return table;
        }
        private DataTable DataTranfer(DataTable dataTable, List<SinhVien> sinhViens)
        {
            for (int i = 0; i < sinhViens.Count; i++)
            {
                dataTable.Rows.Add(i + 1, sinhViens[i].IDSinhVien, sinhViens[i].HoTen,
                    sinhViens[i].NgaySinh, sinhViens[i].QueQuan, sinhViens[i].DiaChiHT
                    , sinhViens[i].KhoaDki, sinhViens[i].SoTCDaDat, sinhViens[i].SoTCDaDki
                    , sinhViens[i].DiemTichLuy, sinhViens[i].IDLop);
            }
            return dataTable;
        }

        private void txbSearchsv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                string search = txbSearchsv.Text.ToString();
                sinhViens = new List<SinhVien>();
                sinhViens = SinhVienDAO.Instance.Search(search);
                dtgStudents.DataSource = null;
                DataTable table = CustomHeaderText();
                dtgStudents.DataSource = DataTranfer(table, sinhViens);
            }
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if (ValidateData()) {
                MessageBox.Show("Bạn phải nhập đầy đủ thông tin cho sinh viên không thì toang !!!", "Thông báo");
                return;
            }
            CreateOrUpdate();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ValidateData())
            {
                MessageBox.Show("Bạn phải nhập đầy đủ thông tin cho sinh viên không thì toang !!!", "Thông báo");
                return;
            }
            CreateOrUpdate(true);
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //TODO
        }

        private void btnClearData_Click(object sender, EventArgs e)
        {
            ClearData();
        }
        private void ClearData()
        {
            txbStudentID.Text = string.Empty;
            txbStudentName.Text = string.Empty;
            txbCurrentAddress.Text = string.Empty;
            txbHometown.Text = string.Empty;
            dtpDateOfbirth.Value = DateTime.Now;

        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(txbStudentID.Text.ToString())
                || string.IsNullOrEmpty(txbStudentName.Text.ToString())
                || string.IsNullOrEmpty(txbCurrentAddress.Text.ToString())
                || string.IsNullOrEmpty(txbHometown.Text.ToString())
                || string.IsNullOrEmpty(cbbClass.Text.ToString())
                || string.IsNullOrEmpty(cbbGender.Text.ToString()))
                return true;
            return false;
        }
        private void CreateOrUpdate(bool isUpdate = false)
        {
            var action = isUpdate ? "Sửa" : "Thêm";
            var studentId = txbStudentID.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : txbStudentID.Text.ToString().Trim();
            var studentName = txbStudentName.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : txbStudentName.Text.ToString().Trim();
            var hometown = txbHometown.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : txbHometown.Text.ToString().Trim();
            var currentAddress = txbCurrentAddress.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : txbCurrentAddress.Text.ToString().Trim();
            var classID = cbbClass.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : cbbClass.Text.ToString().Trim();
            var gender = cbbGender.Text.ToString().Trim().Equals(string.Empty) ? string.Empty : cbbGender.Text.ToString().Trim();
            var dateOfBirth = new DateTime();
            if (string.IsNullOrEmpty(dtpDateOfbirth.Text.ToString()))
                dateOfBirth = DateTime.Now;
            else
                dateOfBirth = DateTime.Parse(dtpDateOfbirth.Text.ToString());
            DialogResult dialogResult = MessageBox.Show($"{action} sinh viên", $"Bạn có chắc chắn muốn {action} sinh viên: {studentName}", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                var stDTO = new SinhVienDTO()
                {
                    IDSinhVien = studentId,
                    HoTen = studentName,
                    QueQuan = hometown,
                    DiaChiHT = currentAddress,
                    NgaySinh = dateOfBirth,
                    IDLop = classID,
                    GioiTinh = gender
                };
                // Update
                if (isUpdate)
                {
                    var st = SinhVienDAO.Instance.GetSinhVienById(studentId);
                    if (st != null)
                    {
                        if (SinhVienDAO.Instance.Update(stDTO) != 0)
                        {
                            MessageBox.Show("Sửa thành công !!!", "Thông báo");
                            LoadData(true);
                        }
                        else
                        {
                            MessageBox.Show("Sửa thất bại !!!", "Thông báo");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sửa thất bại!!! Sinh viên này không tồn tại trong hệ thống !!!", "Thông báo");
                    }
                }
                // Add
                else
                {
                    var st = SinhVienDAO.Instance.GetSinhVienById(studentId);
                    if (st == null)
                    {
                        if (SinhVienDAO.Instance.Create(stDTO) != 0)
                        {
                            MessageBox.Show("Thêm thành công !!!", "Thông báo");
                            ClearData();
                            LoadData(true);
                        }
                        else
                        {
                            MessageBox.Show("Thêm thất bại !!!", "Thông báo");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Thêm thất bại!!! Sinh viên này phải không tồn tại trong hệ thống !!!", "Thông báo");
                    }
                }
            }
        }
        private void dtgStudents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex != -1)
            {
                var studentId = dtgStudents.Rows[e.RowIndex].Cells[1].Value.ToString();
                if (!string.IsNullOrEmpty(studentId))
                    GetDataByStudentID(studentId);
                else
                    GetDataByStudentID("");
            }
        }
        private void GetDataByStudentID(string studentId)
        {
            var st = SinhVienDAO.Instance.GetSinhVienById(studentId);
            txbStudentID.Text = st.IDSinhVien;
            txbStudentName.Text = st.HoTen;
            txbCurrentAddress.Text = st.DiaChiHT;
            txbHometown.Text = st.QueQuan;
            dtpDateOfbirth.Value = st.NgaySinh;
            cbbClass.Text = st.IDLop;
            cbbGender.Text = st.GioiTinh;
        }
    }
}
